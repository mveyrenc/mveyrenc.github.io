<?php

namespace tp2;

/**
 * Class Enterprise
 *
 * @package tp2
 */
class Enterprise
{
    /**
     * @param Person $person
     */
    public function add(Person $person)
    {
        // TO IMPLEMENT
    }

    /**
     * @param Person $personToRemove
     */
    public function remove(Person $personToRemove)
    {
        // TO IMPLEMENT
    }

    /**
     * @param Person $person
     * @return boolean
     */
    public function employ(Person $person)
    {
        // TO IMPLEMENT
    }
}