<?php

namespace tp2;

/**
 * Class Person
 *
 * @package tp2
 */
class Person
{
    /**
     * @param string $name
     */
    public function __construct($name)
    {
        // TO IMPLEMENT
    }

    /**
     * @return string
     */
    public function getName()
    {
        // TO IMPLEMENT
    }
}