<?php

namespace tests\tp2;

/**
 * Class PersonTest
 *
 * @package tests\tp2
 */
class PersonTest extends \PHPUnit_Framework_TestCase
{

}
