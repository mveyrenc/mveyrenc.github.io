<?php

namespace tests\tp2;

/**
 * Class HRDepartmentTest
 *
 * @package tests\tp2
 */
class HRDepartmentTest extends \PHPUnit_Framework_TestCase
{

}
