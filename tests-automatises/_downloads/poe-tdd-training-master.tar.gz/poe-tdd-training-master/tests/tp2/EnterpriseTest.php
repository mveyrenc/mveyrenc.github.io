<?php

namespace tests\tp2;

/**
 * Class EnterpriseTest
 *
 * @package tests\tp2
 */
class EnterpriseTest extends \PHPUnit_Framework_TestCase
{

}
