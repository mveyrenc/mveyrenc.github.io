<?php

namespace tp2\Exception;

/**
 * Class AlreadyEmployedException
 * @package tp2\Exception
 */
class AlreadyEmployedException extends \Exception
{

}