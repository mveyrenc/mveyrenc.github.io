<?php

namespace tp2;

/**
 * Class Enterprise
 *
 * @package tp2
 */
class Enterprise
{
    /**
     * @var Person[]
     */
    protected $persons = [];

    /**
     * @param Person $person
     */
    public function add(Person $person)
    {
        $this->persons[] = $person;
    }

    /**
     * @param Person $personToRemove
     */
    public function remove(Person $personToRemove)
    {
        $personIndex = array_search($personToRemove, $this->persons, true);
        if (false !== $personIndex) {
            unset($this->persons[$personIndex]);
        }
    }

    /**
     * @param Person $person
     * @return boolean
     */
    public function employ(Person $person)
    {
        return in_array($person, $this->persons, true);
    }
}
