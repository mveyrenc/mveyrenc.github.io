<?php


namespace tp2\Exception;

/**
 * Class NoEmployedException
 * @package tp2\Exception
 */
class NoEmployedException extends \Exception
{

}