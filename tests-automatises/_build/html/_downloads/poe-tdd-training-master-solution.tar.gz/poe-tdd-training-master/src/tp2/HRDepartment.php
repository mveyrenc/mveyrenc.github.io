<?php

namespace tp2;

use tp2\Exception\AlreadyEmployedException;
use tp2\Exception\NoEmployedException;

/**
 * Class HRDepartment
 *
 * @package tp2
 */
class HRDepartment
{
    /**
     * @var Enterprise
     */
    protected $enterprise;

    /**
     * @var SalaryTable
     */
    protected $salaryTable;

    /**
     * HRDepartment constructor.
     * @param Enterprise $entreprise
     */
    public function __construct(Enterprise $entreprise, SalaryTable $salaryTable)
    {
        $this->enterprise = $entreprise;
        $this->salaryTable = $salaryTable;
    }

    /**
     * @param Person $person
     * @param float $salary
     * @throws \tp2\Exception\AlreadyEmployedException When the given person is already an employee
     */
    public function hire(Person $person, $salary)
    {
        if ($this->enterprise->employ($person)) {
            throw new AlreadyEmployedException();
        }

        $this->enterprise->add($person);
        $this->salaryTable->grantSalary($salary, $person);
    }

    /**
     * @param Person $person
     * @throws \tp2\Exception\NoEmployedException When the given person is not an employee
     */
    public function fire(Person $person)
    {
        if (!$this->enterprise->employ($person)) {
            throw new NoEmployedException();
        }

        $this->enterprise->remove($person);
    }

    /**
     * @param Person $person
     * @return boolean
     */
    public function isEmployee(Person $person)
    {
        return $this->enterprise->employ($person);
    }

    /**
     * @param Person $person
     * @param float  $percentage
     * @return float
     */
    public function increaseSalary(Person $person, $percentage)
    {
        $salary = $this->salaryTable->getSalary($person);
        if (null !== $salary) {
            $salary *= (1 + $percentage / 100);
            $this->salaryTable->grantSalary($salary * (1 + $percentage / 100), $person);
        }

        return $salary;
    }

    /**
     * @return float
     */
    public function getAverageSalary()
    {
        return $this->salaryTable->getAverageSalary();
    }
}
