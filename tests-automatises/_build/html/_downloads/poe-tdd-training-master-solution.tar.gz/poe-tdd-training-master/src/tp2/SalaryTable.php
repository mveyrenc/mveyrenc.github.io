<?php


namespace tp2;


class SalaryTable
{
    /**
     * @var Person[]
     */
    protected $persons = [];

    /**
     * @var float[]
     */
    protected $salaries = [];

    /**
     * @param float  $salary
     * @param Person $person
     */
    public function grantSalary($salary, Person $person)
    {
        $personIndex = array_search($person, $this->persons, true);
        if (false === $personIndex) {
            $personIndex = count($this->persons);
        }
        $this->persons[$personIndex] = $person;
        $this->salaries[$personIndex] = $salary;
    }

    /**
     * @param Person $person
     * @return float
     */
    public function getSalary(Person $person)
    {
        $personIndex = array_search($person, $this->persons, true);
        if (false !== $personIndex) {
            return $this->salaries[$personIndex];
        }

        return null;
    }

    /**
     * @return float
     */
    public function getAverageSalary()
    {
        return array_sum($this->salaries) / count($this->salaries);
    }
}