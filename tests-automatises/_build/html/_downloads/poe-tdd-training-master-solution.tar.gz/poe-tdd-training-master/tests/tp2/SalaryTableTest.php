<?php


namespace tests\tp2;

use tp2\Person;
use tp2\SalaryTable;

class SalaryTableTest extends \PHPUnit_Framework_TestCase
{
    /**
     * @var SalaryTable
     */
    protected $salaryTable;

    /**
     * @var Person
     */
    protected $personWithSalary;

    /**
     * @var Person
     */
    protected $personWithoutSalary;

    /**
     *
     */
    public function setUp()
    {
        $this->salaryTable = new SalaryTable();
        $this->personWithSalary = new Person('John');
        $this->personWithoutSalary = new Person('Jack');
    }

    /**
     *
     */
    public function testGetSalary()
    {
        $this->salaryTable->grantSalary(100, $this->personWithSalary);
        static::assertEquals(100, $this->salaryTable->getSalary($this->personWithSalary));
        $this->salaryTable->grantSalary(200, $this->personWithSalary);
        static::assertEquals(200, $this->salaryTable->getSalary($this->personWithSalary));

        static::assertNull($this->salaryTable->getSalary($this->personWithoutSalary));
    }
}
