<?php

namespace tests\tp2;

use tp2\Person;

/**
 * Class PersonTest
 *
 * @package tests\tp2
 */
class PersonTest extends \PHPUnit_Framework_TestCase
{

    /**
     * @var Person
     */
    protected $person;

    /**
     *
     */
    public function setUp()
    {
        $this->person = new Person('John');
    }

    /**
     *
     */
    public function testGetName()
    {
        static::assertEquals('John', $this->person->getName());
    }
}
