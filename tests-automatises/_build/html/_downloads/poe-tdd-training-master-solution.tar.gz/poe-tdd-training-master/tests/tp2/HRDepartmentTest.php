<?php

namespace tests\tp2;

use tp2\Enterprise;
use tp2\HRDepartment;
use tp2\Person;
use tp2\SalaryTable;

/**
 * Class HRDepartmentTest
 *
 * @package tests\tp2
 */
class HRDepartmentTest extends \PHPUnit_Framework_TestCase
{

    /**
     * @var Person
     */
    protected $person;

    /**
     * @var HRDepartment
     */
    protected $hrDepartment;

    /**
     *
     */
    public function setUp()
    {
        $this->person = new Person('John');
        $this->hrDepartment = new HRDepartment(new Enterprise(), new SalaryTable());
    }

    /**
     * @throws \tp2\Exception\AlreadyEmployedException
     */
    public function testHire()
    {
        static::assertFalse($this->hrDepartment->isEmployee($this->person));
        $this->hrDepartment->hire($this->person, 100);
        static::assertTrue($this->hrDepartment->isEmployee($this->person));
    }

    /**
     * @expectedException \tp2\Exception\AlreadyEmployedException
     */
    public function testReHire()
    {
        $this->hrDepartment->hire($this->person, 100);
        $this->hrDepartment->hire($this->person, 100);
    }

    /**
     * @throws \tp2\Exception\AlreadyEmployedException
     * @throws \tp2\Exception\NoEmployedException
     */
    public function testFire()
    {
        $this->hrDepartment->hire($this->person, 100);
        static::assertTrue($this->hrDepartment->isEmployee($this->person));
        $this->hrDepartment->fire($this->person);
        static::assertFalse($this->hrDepartment->isEmployee($this->person));

    }

    /**
     * @expectedException \tp2\Exception\NoEmployedException
     */
    public function testFireUnexistingEmploy()
    {
        $this->hrDepartment->fire($this->person);
    }

    /**
     * @throws \tp2\Exception\AlreadyEmployedException
     */
    public function testIsEmployee()
    {
        static::assertFalse($this->hrDepartment->isEmployee($this->person));
        $this->hrDepartment->hire($this->person, 100);
        static::assertTrue($this->hrDepartment->isEmployee($this->person));
    }

    /**
     *
     */
    public function testIncreaseSalary()
    {
        $this->hrDepartment->hire($this->person, 100);
        static::assertEquals(150, $this->hrDepartment->increaseSalary($this->person, 50));
    }

    /**
     * @throws \tp2\Exception\AlreadyEmployedException
     */
    public function testGetAverageSalary()
    {
        $this->hrDepartment->hire(new Person('John'), 100);
        $this->hrDepartment->hire(new Person('John'), 200);
        $this->hrDepartment->hire(new Person('John'), 300);
        static::assertEquals(200, $this->hrDepartment->getAverageSalary());
    }
}
