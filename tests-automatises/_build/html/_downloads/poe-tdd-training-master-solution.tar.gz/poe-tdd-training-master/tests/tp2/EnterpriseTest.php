<?php

namespace tests\tp2;

use tp2\Enterprise;
use tp2\Person;

/**
 * Class EnterpriseTest
 *
 * @package tests\tp2
 */
class EnterpriseTest extends \PHPUnit_Framework_TestCase
{
    /**
     * @var Enterprise
     */
    protected $enterprise;

    /**
     * @var Person
     */
    protected $person;

    /**
     *
     */
    public function setUp()
    {
        $this->enterprise = new Enterprise();
        $this->person = new Person('John');
    }

    /**
     *
     */
    public function testAdd()
    {
        static::assertFalse($this->enterprise->employ($this->person));
        $this->enterprise->add($this->person);
        static::assertTrue($this->enterprise->employ($this->person));
    }

    /**
     *
     */
    public function testRemove()
    {
        $this->enterprise->add($this->person);
        static::assertTrue($this->enterprise->employ($this->person));
        $this->enterprise->remove($this->person);
        static::assertFalse($this->enterprise->employ($this->person));
    }

    /**
     *
     */
    public function testEmploy()
    {
        static::assertFalse($this->enterprise->employ($this->person));
        $this->enterprise->add($this->person);
        static::assertTrue($this->enterprise->employ($this->person));
    }
}
