<?php

namespace tests\tp1;

use tp1\ParameterBag;

/**
 * Class ParameterBagTest
 *
 * @package tests\tp1
 */
class ParameterBagTest extends \PHPUnit_Framework_TestCase
{
    /**
     * @var ParameterBag
     */
    protected $bag;

    /**
     * {@inheritDoc}
     */
    public function setUp()
    {
        $this->bag = new ParameterBag(array('foo' => 'bar', 'baz' => '123'));
    }

    /**
     *
     */
    public function testCount()
    {
        static::assertEquals(2, $this->bag->count());
    }

    /**
     *
     */
    public function testGet()
    {
        static::assertEquals('bar', $this->bag->get('foo'));
        static::assertEquals(null, $this->bag->get('pony'));
        static::assertEquals('pink', $this->bag->get('pony', 'pink'));
    }

    /**
     *
     */
    public function testGetInt()
    {
        static::assertEquals(123, $this->bag->getInt('baz'));
        static::assertEquals(0, $this->bag->getInt('pony'));
        static::assertEquals(0, $this->bag->getInt('pony', 'pink'));
    }

    /**
     *
     */
    public function testSet()
    {
        static::assertEquals('bar', $this->bag->get('foo'));
        $this->bag->set('foo', 'foo');
        static::assertEquals('foo', $this->bag->get('foo'));
    }

    /**
     *
     */
    public function testHas()
    {
        static::assertTrue($this->bag->has('foo'));
        static::assertFalse($this->bag->has('bar'));
    }

    /**
     *
     */
    public function testRemove()
    {
        static::assertEquals('bar', $this->bag->get('foo'));
        $this->bag->remove('bar');
        static::assertFalse($this->bag->has('bar'));
    }

    /**
     *
     */
    public function testAll()
    {
        static::assertEquals(array('foo' => 'bar', 'baz' => '123'), $this->bag->all());
    }

    /**
     *
     */
    public function testKeys()
    {
        static::assertEquals(array('foo', 'baz'), $this->bag->keys());
    }

    /**
     *
     */
    public function testAdd()
    {
        static::assertFalse($this->bag->has('run'));
        $this->bag->add(array('run' => 'run'));
        static::assertEquals('run', $this->bag->get('run'));
    }
}
